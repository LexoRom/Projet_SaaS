const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const MONGO_URI = process.env.MONGO_URI || "mongodb://localhost:27017/saas_project";
const JWT_SECRET = process.env.JWT_SECRET || "change-me-in-production";
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "8h";

const companySchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  createdAt: { type: Date, default: Date.now }
});

const userSchema = new mongoose.Schema({
  companyId: { type: mongoose.Schema.Types.ObjectId, ref: "Company", required: true, index: true },
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, trim: true, lowercase: true },
  passwordHash: { type: String, required: true },
  role: { type: String, enum: ["admin", "member"], default: "member" },
  createdAt: { type: Date, default: Date.now }
});
userSchema.index({ companyId: 1, email: 1 }, { unique: true });

const projectSchema = new mongoose.Schema({
  companyId: { type: mongoose.Schema.Types.ObjectId, ref: "Company", required: true, index: true },
  name: { type: String, required: true, trim: true },
  description: { type: String, default: "" },
  userIds: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  createdAt: { type: Date, default: Date.now }
});
projectSchema.index({ companyId: 1, createdAt: -1 });

const taskSchema = new mongoose.Schema({
  companyId: { type: mongoose.Schema.Types.ObjectId, ref: "Company", required: true, index: true },
  projectId: { type: mongoose.Schema.Types.ObjectId, ref: "Project", required: true, index: true },
  title: { type: String, required: true, trim: true },
  description: { type: String, default: "" },
  assigneeId: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
  status: { type: String, enum: ["todo", "doing", "done"], default: "todo" },
  priority: { type: String, enum: ["low", "medium", "high"], default: "medium" },
  dueDate: { type: Date, default: null },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});
taskSchema.index({ companyId: 1, projectId: 1, status: 1 });

const Company = mongoose.model("Company", companySchema);
const User = mongoose.model("User", userSchema);
const Project = mongoose.model("Project", projectSchema);
const Task = mongoose.model("Task", taskSchema);

function signToken(user) {
  return jwt.sign(
    { userId: user._id.toString(), companyId: user.companyId.toString(), role: user.role },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Authentification requise." });
  try {
    req.auth = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "Token invalide ou expiré." });
  }
}

function adminOnly(req, res, next) {
  if (req.auth.role !== "admin") return res.status(403).json({ error: "Droits administrateur requis." });
  next();
}

function validId(id) {
  return mongoose.isValidObjectId(id);
}

async function companyExists(companyId) {
  return Company.exists({ _id: companyId });
}

async function userInTenant(userId, companyId) {
  return User.findOne({ _id: userId, companyId });
}

async function projectInTenant(projectId, companyId) {
  return Project.findOne({ _id: projectId, companyId });
}

// Health
app.get("/api/health", async (req, res) => {
  res.json({ status: "ok", mongo: mongoose.connection.readyState === 1 });
});

// Bootstrap: creates the first company and admin only if no companies exist.
app.post("/api/bootstrap", async (req, res) => {
  if (await Company.exists({})) {
    return res.status(409).json({ error: "Le bootstrap est déjà effectué." });
  }
  const { companyName, name, email, password } = req.body;
  if (!companyName || !name || !email || !password || password.length < 6) {
    return res.status(400).json({ error: "companyName, name, email et un mot de passe d'au moins 6 caractères sont requis." });
  }
  const company = await Company.create({ name: companyName });
  const passwordHash = await bcrypt.hash(password, 12);
  const user = await User.create({ companyId: company._id, name, email, passwordHash, role: "admin" });
  res.status(201).json({ company: { id: company._id, name: company.name }, user: { id: user._id, name: user.name, email: user.email, role: user.role } });
});

// Auth
app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email: String(email || "").toLowerCase() });
  if (!user || !(await bcrypt.compare(password || "", user.passwordHash))) {
    return res.status(401).json({ error: "Email ou mot de passe incorrect." });
  }
  const company = await Company.findById(user.companyId);
  res.json({
    token: signToken(user),
    user: { id: user._id, name: user.name, email: user.email, role: user.role },
    company: { id: company._id, name: company.name }
  });
});

app.get("/api/me", auth, async (req, res) => {
  const user = await User.findOne({ _id: req.auth.userId, companyId: req.auth.companyId }).select("-passwordHash");
  const company = await Company.findById(req.auth.companyId);
  if (!user || !company) return res.status(401).json({ error: "Session invalide." });
  res.json({ user, company });
});

// Companies: tenant-scoped except creation/deletion, which are admin operations.
app.get("/api/company", auth, async (req, res) => {
  const company = await Company.findById(req.auth.companyId);
  res.json(company);
});

app.patch("/api/company", auth, adminOnly, async (req, res) => {
  const company = await Company.findByIdAndUpdate(
    req.auth.companyId,
    { name: req.body.name },
    { new: true, runValidators: true }
  );
  res.json(company);
});

// Users
app.get("/api/users", auth, async (req, res) => {
  const users = await User.find({ companyId: req.auth.companyId }).select("-passwordHash").sort({ name: 1 });
  res.json(users);
});

app.post("/api/users", auth, adminOnly, async (req, res) => {
  const { name, email, password, role = "member" } = req.body;
  if (!name || !email || !password || password.length < 6) {
    return res.status(400).json({ error: "name, email et mot de passe (6 caractères minimum) sont requis." });
  }
  const passwordHash = await bcrypt.hash(password, 12);
  try {
    const user = await User.create({ companyId: req.auth.companyId, name, email, passwordHash, role });
    res.status(201).json({ id: user._id, name: user.name, email: user.email, role: user.role });
  } catch (e) {
    if (e.code === 11000) return res.status(409).json({ error: "Cet email existe déjà dans l'entreprise." });
    throw e;
  }
});

app.delete("/api/users/:id", auth, adminOnly, async (req, res) => {
  if (!validId(req.params.id)) return res.status(400).json({ error: "ID invalide." });
  if (req.params.id === req.auth.userId) return res.status(400).json({ error: "Impossible de supprimer son propre compte." });
  const user = await User.findOneAndDelete({ _id: req.params.id, companyId: req.auth.companyId });
  if (!user) return res.status(404).json({ error: "Utilisateur introuvable." });
  await Project.updateMany({ companyId: req.auth.companyId }, { $pull: { userIds: user._id } });
  await Task.updateMany({ companyId: req.auth.companyId, assigneeId: user._id }, { $set: { assigneeId: null } });
  res.status(204).end();
});

// Projects
app.get("/api/projects", auth, async (req, res) => {
  const projects = await Project.find({ companyId: req.auth.companyId }).populate("userIds", "name email role").sort({ createdAt: -1 });
  res.json(projects);
});

app.post("/api/projects", auth, async (req, res) => {
  const { name, description = "", userIds = [] } = req.body;
  if (!name) return res.status(400).json({ error: "Le nom du projet est requis." });
  const ids = [...new Set(userIds.map(String))];
  const count = await User.countDocuments({ companyId: req.auth.companyId, _id: { $in: ids } });
  if (count !== ids.length) return res.status(400).json({ error: "Tous les utilisateurs du projet doivent appartenir à votre entreprise." });
  const project = await Project.create({ companyId: req.auth.companyId, name, description, userIds: ids });
  res.status(201).json(await Project.findById(project._id).populate("userIds", "name email role"));
});

app.patch("/api/projects/:id", auth, async (req, res) => {
  if (!validId(req.params.id)) return res.status(400).json({ error: "ID invalide." });
  const project = await projectInTenant(req.params.id, req.auth.companyId);
  if (!project) return res.status(404).json({ error: "Projet introuvable." });
  const update = {};
  if (req.body.name !== undefined) update.name = req.body.name;
  if (req.body.description !== undefined) update.description = req.body.description;
  if (req.body.userIds !== undefined) {
    const ids = [...new Set(req.body.userIds.map(String))];
    const count = await User.countDocuments({ companyId: req.auth.companyId, _id: { $in: ids } });
    if (count !== ids.length) return res.status(400).json({ error: "Un utilisateur n'appartient pas à l'entreprise." });
    update.userIds = ids;
  }
  const saved = await Project.findOneAndUpdate(
    { _id: req.params.id, companyId: req.auth.companyId },
    update, { new: true, runValidators: true }
  ).populate("userIds", "name email role");
  res.json(saved);
});

app.delete("/api/projects/:id", auth, async (req, res) => {
  if (!validId(req.params.id)) return res.status(400).json({ error: "ID invalide." });
  const project = await Project.findOneAndDelete({ _id: req.params.id, companyId: req.auth.companyId });
  if (!project) return res.status(404).json({ error: "Projet introuvable." });
  await Task.deleteMany({ projectId: project._id, companyId: req.auth.companyId });
  res.status(204).end();
});

// Tasks / Kanban
app.get("/api/projects/:projectId/tasks", auth, async (req, res) => {
  if (!validId(req.params.projectId)) return res.status(400).json({ error: "ID invalide." });
  const project = await projectInTenant(req.params.projectId, req.auth.companyId);
  if (!project) return res.status(404).json({ error: "Projet introuvable." });
  const tasks = await Task.find({ projectId: project._id, companyId: req.auth.companyId })
    .populate("assigneeId", "name email")
    .sort({ createdAt: -1 });
  res.json(tasks);
});

app.post("/api/projects/:projectId/tasks", auth, async (req, res) => {
  if (!validId(req.params.projectId)) return res.status(400).json({ error: "ID invalide." });
  const project = await projectInTenant(req.params.projectId, req.auth.companyId);
  if (!project) return res.status(404).json({ error: "Projet introuvable." });
  const { title, description = "", assigneeId = null, status = "todo", priority = "medium", dueDate = null } = req.body;
  if (!title) return res.status(400).json({ error: "Le titre est requis." });
  if (assigneeId && !(await userInTenant(assigneeId, req.auth.companyId))) {
    return res.status(400).json({ error: "L'utilisateur assigné n'appartient pas à l'entreprise." });
  }
  if (assigneeId && !project.userIds.some(id => id.toString() === assigneeId.toString())) {
    return res.status(400).json({ error: "L'utilisateur assigné doit être membre du projet." });
  }
  const task = await Task.create({ companyId: req.auth.companyId, projectId: project._id, title, description, assigneeId, status, priority, dueDate });
  res.status(201).json(await Task.findById(task._id).populate("assigneeId", "name email"));
});

app.patch("/api/tasks/:id", auth, async (req, res) => {
  if (!validId(req.params.id)) return res.status(400).json({ error: "ID invalide." });
  const task = await Task.findOne({ _id: req.params.id, companyId: req.auth.companyId });
  if (!task) return res.status(404).json({ error: "Tâche introuvable." });
  const update = {};
  for (const field of ["title", "description", "status", "priority", "dueDate"]) {
    if (req.body[field] !== undefined) update[field] = req.body[field];
  }
  if (req.body.assigneeId !== undefined) {
    if (req.body.assigneeId === null || req.body.assigneeId === "") {
      update.assigneeId = null;
    } else {
      const user = await userInTenant(req.body.assigneeId, req.auth.companyId);
      const project = await projectInTenant(task.projectId, req.auth.companyId);
      if (!user || !project || !project.userIds.some(id => id.toString() === req.body.assigneeId.toString())) {
        return res.status(400).json({ error: "Assignation interdite: utilisateur hors entreprise ou hors projet." });
      }
      update.assigneeId = req.body.assigneeId;
    }
  }
  update.updatedAt = new Date();
  const saved = await Task.findOneAndUpdate({ _id: task._id, companyId: req.auth.companyId }, update, { new: true, runValidators: true })
    .populate("assigneeId", "name email");
  res.json(saved);
});

app.delete("/api/tasks/:id", auth, async (req, res) => {
  if (!validId(req.params.id)) return res.status(400).json({ error: "ID invalide." });
  const task = await Task.findOneAndDelete({ _id: req.params.id, companyId: req.auth.companyId });
  if (!task) return res.status(404).json({ error: "Tâche introuvable." });
  res.status(204).end();
});

// Error handling
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Erreur interne du serveur." });
});

async function start() {
  await mongoose.connect(MONGO_URI);
  console.log("MongoDB connected");
  app.listen(PORT, () => console.log(`SaaS app listening on port ${PORT}`));
}

start().catch(err => {
  console.error("Startup error:", err);
  process.exit(1);
});
