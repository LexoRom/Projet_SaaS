const $ = s => document.querySelector(s);
let token = localStorage.getItem("token");
let me = null, users = [], projects = [], currentProject = null, tasks = [];

const api = async (url, options={}) => {
  const headers = {"Content-Type":"application/json", ...(options.headers||{})};
  if (token) headers.Authorization = `Bearer ${token}`;
  const r = await fetch(url, {...options, headers});
  if (r.status === 204) return null;
  const data = await r.json().catch(()=>({}));
  if (!r.ok) throw new Error(data.error || "Erreur");
  return data;
};

function msg(text){ $("#authMsg").textContent = text || ""; }
function showApp(on){ $("#authView").classList.toggle("hidden", on); $("#appView").classList.toggle("hidden", !on); $("#sessionBar").classList.toggle("hidden", !on); }

async function loadSession(){
  try {
    const data = await api("/api/me");
    me = data.user;
    $("#companyLabel").textContent = data.company.name;
    $("#userLabel").textContent = `${me.name} (${me.role})`;
    showApp(true);
    await Promise.all([loadUsers(), loadProjects()]);
  } catch {
    token = null; localStorage.removeItem("token"); showApp(false);
  }
}

async function loadUsers(){
  users = await api("/api/users");
  renderUsers();
  renderAssignees();
}
function renderUsers(){
  $("#usersList").innerHTML = users.map(u => `
    <div class="member"><span>${escapeHtml(u.name)} — ${escapeHtml(u.email)} <span class="badge">${u.role}</span></span>
    ${u.id === me?.id ? "" : `<button type="button" class="danger" onclick="removeUser('${u._id}')">Supprimer</button>`}</div>
  `).join("");
}
function renderAssignees(){
  $("#taskAssignee").innerHTML = `<option value="">Non assignée</option>` +
    users.map(u => `<option value="${u._id}">${escapeHtml(u.name)}</option>`).join("");
}
function renderProjectMembers(){
  $("#projectMembers").innerHTML = users.map(u => `<label class="member"><input type="checkbox" name="members" value="${u._id}"> ${escapeHtml(u.name)}</label>`).join("");
}

async function loadProjects(){
  projects = await api("/api/projects");
  const sel = $("#projectSelect");
  sel.innerHTML = projects.map(p => `<option value="${p._id}">${escapeHtml(p.name)}</option>`).join("");
  if (!projects.length){ currentProject=null; renderBoard(); return; }
  if (!currentProject || !projects.some(p=>p._id===currentProject._id)) currentProject=projects[0];
  sel.value=currentProject._id;
  await loadTasks();
}
async function loadTasks(){
  currentProject = projects.find(p=>p._id === $("#projectSelect").value) || currentProject;
  if (!currentProject){ renderBoard(); return; }
  tasks = await api(`/api/projects/${currentProject._id}/tasks`);
  renderBoard();
}
function renderBoard(){
  $("#projectName").textContent = currentProject?.name || "Aucun projet";
  $("#projectDescription").textContent = currentProject?.description || "";
  ["todo","doing","done"].forEach(s => $("#"+s).innerHTML="");
  for (const t of tasks){
    const el=document.createElement("article");
    el.className="task"; el.draggable=true; el.dataset.id=t._id;
    el.innerHTML=`<strong>${escapeHtml(t.title)}</strong>
      <span class="badge priority-${t.priority}">${t.priority}</span>
      <small>${escapeHtml(t.description||"")}</small>
      <small>👤 ${escapeHtml(t.assigneeId?.name || "Non assignée")}</small>
      ${t.dueDate ? `<small>📅 ${new Date(t.dueDate).toLocaleDateString("fr-FR")}</small>`:""}
      <div class="actions"><button onclick="editStatus('${t._id}')">Déplacer</button><button class="danger" onclick="deleteTask('${t._id}')">Suppr.</button></div>`;
    el.addEventListener("dragstart", e=>e.dataTransfer.setData("text/plain",t._id));
    $("#"+t.status).appendChild(el);
  }
}
async function editStatus(id){
  const t=tasks.find(x=>x._id===id);
  const status=prompt("Statut: todo, doing ou done",t.status);
  if(!status || !["todo","doing","done"].includes(status)) return;
  await api(`/api/tasks/${id}`,{method:"PATCH",body:JSON.stringify({status})}); await loadTasks();
}
async function deleteTask(id){
  if(!confirm("Supprimer cette tâche ?")) return;
  await api(`/api/tasks/${id}`,{method:"DELETE"}); await loadTasks();
}
async function removeUser(id){
  if(!confirm("Supprimer cet utilisateur ?")) return;
  await api(`/api/users/${id}`,{method:"DELETE"}); await loadUsers(); await loadProjects();
}
function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}

$("#loginTab").onclick=()=>{$("#loginForm").classList.remove("hidden");$("#bootstrapForm").classList.add("hidden");$("#loginTab").classList.add("active");$("#bootstrapTab").classList.remove("active")};
$("#bootstrapTab").onclick=()=>{$("#bootstrapForm").classList.remove("hidden");$("#loginForm").classList.add("hidden");$("#bootstrapTab").classList.add("active");$("#loginTab").classList.remove("active")};
$("#loginForm").onsubmit=async e=>{e.preventDefault();msg("");try{const f=new FormData(e.target);const d=await api("/api/auth/login",{method:"POST",body:JSON.stringify(Object.fromEntries(f))});token=d.token;localStorage.setItem("token",token);await loadSession()}catch(err){msg(err.message)}};
$("#bootstrapForm").onsubmit=async e=>{e.preventDefault();msg("");try{const f=new FormData(e.target);await api("/api/bootstrap",{method:"POST",body:JSON.stringify(Object.fromEntries(f))});msg("Entreprise créée. Vous pouvez maintenant vous connecter.");$("#loginTab").click()}catch(err){msg(err.message)}};
$("#logoutBtn").onclick=()=>{token=null;localStorage.removeItem("token");showApp(false)};
$("#projectSelect").onchange=loadTasks;
$("#newProjectBtn").onclick=()=>{renderProjectMembers();$("#projectDialog").showModal()};
$("#newTaskBtn").onclick=()=>{if(!currentProject)return alert("Créez d'abord un projet.");renderAssignees();$("#taskDialog").showModal()};
$("#usersBtn").onclick=()=>{$("#usersDialog").showModal()};
$("#deleteProjectBtn").onclick=async()=>{if(!currentProject)return;if(!confirm("Supprimer le projet et ses tâches ?"))return;await api(`/api/projects/${currentProject._id}`,{method:"DELETE"});currentProject=null;await loadProjects()};
$("#projectForm").onsubmit=async e=>{e.preventDefault();try{const f=new FormData(e.target);const userIds=[...document.querySelectorAll('input[name="members"]:checked')].map(x=>x.value);await api("/api/projects",{method:"POST",body:JSON.stringify({name:f.get("name"),description:f.get("description"),userIds})});e.target.reset();$("#projectDialog").close();await loadProjects()}catch(err){alert(err.message)}};
$("#taskForm").onsubmit=async e=>{e.preventDefault();try{const f=new FormData(e.target);await api(`/api/projects/${currentProject._id}/tasks`,{method:"POST",body:JSON.stringify({title:f.get("title"),description:f.get("description"),assigneeId:f.get("assigneeId")||null,priority:f.get("priority"),dueDate:f.get("dueDate")||null})});e.target.reset();$("#taskDialog").close();await loadTasks()}catch(err){alert(err.message)}};
for(const status of ["todo","doing","done"]){
  const z=$("#"+status);
  z.addEventListener("dragover",e=>e.preventDefault());
  z.addEventListener("drop",async e=>{e.preventDefault();const id=e.dataTransfer.getData("text/plain");await api(`/api/tasks/${id}`,{method:"PATCH",body:JSON.stringify({status})});await loadTasks()});
}
$("#userForm").onsubmit=async e=>{e.preventDefault();try{const f=new FormData(e.target);await api("/api/users",{method:"POST",body:JSON.stringify(Object.fromEntries(f))});e.target.reset();await loadUsers()}catch(err){alert(err.message)}};

loadSession();
